package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class LevelActivity extends AppCompatActivity {
    TextView test;
    Button back,tile1,tile2,tile3,tile4;
    int[]tiles={1,3,2,4};
    int[]delays={100,300,100,400};
    Level level=new Level(tiles,delays,R.raw.jojo);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level);
        tile1=findViewById(R.id.tile1);
        tile2=findViewById(R.id.tile2);
        tile3=findViewById(R.id.tile3);
        tile4=findViewById(R.id.tile4);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        test=findViewById(R.id.test);
        back=findViewById(R.id.back);
        Bundle bundle=new Bundle();
        bundle=getIntent().getExtras();

        Long levelID=bundle.getLong("levelID");
        test.setText(levelID.toString());
        Thread thread=new Thread();
        final Intent intent=new Intent(LevelActivity.this,MainActivity.class);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {

        for (int i = 0; i < level.tiles.length; i++) {
            switch (level.tiles[i]) {
                case (1): level.SetButton(tile1, tile2, tile3, tile4, level.delays[i]);
                case(2): level.SetButton(tile2, tile1, tile3, tile4, level.delays[i]);
                case(3): level.SetButton(tile3, tile2, tile1, tile4, level.delays[i]);
                case(4): level.SetButton(tile4, tile2, tile3, tile1, level.delays[i]);
            }
            super.onResume();

        }
    }
}